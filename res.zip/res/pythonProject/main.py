import pygame
from Classes.configs.GameConfig import GameConfig
from Classes.controllers.GameController import GameController

# 等比例缩放因子（可调整：0.3=30%，0.5=50%，1.0=原尺寸）
SCALE_FACTOR = 0.5
# 计算缩放后的窗口尺寸
WINDOW_WIDTH = int(GameConfig.DESIGN_WIDTH * SCALE_FACTOR)
WINDOW_HEIGHT = int(GameConfig.DESIGN_HEIGHT * SCALE_FACTOR)

if __name__ == "__main__":
    # 初始化Pygame
    pygame.init()
    pygame.font.init()

    # 创建缩放后的窗口
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption(f"纸牌游戏（1080×2080，缩放{int(SCALE_FACTOR*100)}%）")

    # 初始化控制器并运行
    controller = GameController(screen, SCALE_FACTOR)
    controller.run()

    # 退出清理
    pygame.font.quit()
    pygame.quit()