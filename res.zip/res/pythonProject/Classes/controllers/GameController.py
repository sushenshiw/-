import pygame
import os
import random
from Classes.configs.GameConfig import GameConfig
from Classes.models.GameState import GameState
from Classes.models.OperationRecord import OperationType, OperationRecord
from Classes.views.HandCardView import HandCardView
from Classes.views.DeskCardView import DeskCardView
from Classes.views.ButtonView import ButtonView
from Classes.managers.CardPileManager import CardPileManager
from Classes.utils.PygameUtils import PygameUtils


class GameController:
    def __init__(self, screen, scale_factor):
        self.screen = screen
        self.config = GameConfig
        self.scale_factor = scale_factor
        self.game_state = GameState()
        self.card_manager = CardPileManager(self.game_state, self.config)
        self.card_manager.init_piles_from_config("level1.json")
        self.init_views()
        self.undo_stack = []
        self.is_animating = False
        self.is_game_success = False  # 游戏成功标志
        print("使用纯色背景：灰色整体 + 黄色主牌区 + 紫色堆牌区")

        # 初始化字体（用于显示"成功"字样）
        pygame.font.init()
        self.success_font = pygame.font.Font(None, 200)  # 大字体
        self.success_color = (255, 0, 0)  # 红色醒目

    def init_views(self):
        self.hand_card_view = HandCardView(self.screen, self.game_state, self.scale_factor, self)  # 传递控制器引用
        self.desk_card_view = DeskCardView(self.screen, self.game_state, self.scale_factor, self)  # 传递控制器引用
        self.undo_button_view = ButtonView(self.screen, self.scale_factor)
        self.hand_card_view.set_click_callback(self.on_hand_card_click)
        self.desk_card_view.set_click_callback(self.on_desk_card_click)
        self.undo_button_view.set_click_callback(self.on_undo_click)

    # 检测主牌区是否全部匹配完毕（左右两列都为空）
    def check_game_success(self):
        left_stack_empty = len(self.game_state.desk_stacks[0]) == 0
        right_stack_empty = len(self.game_state.desk_stacks[1]) == 0
        if left_stack_empty and right_stack_empty and not self.is_game_success:
            self.is_game_success = True
            print("🎉 主牌区所有牌匹配完毕！点击屏幕退出游戏")

    # 手牌点击：游戏成功后禁用
    def on_hand_card_click(self, clicked_card):
        if self.is_game_success or self.is_animating:
            return
        current_hands = self.game_state.current_hand_cards
        if len(current_hands) < 2 or clicked_card != current_hands[0]:
            return

        start_pos = (self.config.HAND_CARD_START_X, self.config.HAND_CARD_Y)
        target_pos = (self.config.DESIGN_WIDTH // 2 - self.config.CARD_WIDTH // 2, self.config.HAND_CARD_Y)

        new_left_card, replaced_card = self.game_state.random_replace_left_card()
        if not new_left_card:
            print("❌ 手牌池为空，无法随机替换")
            return

        self.undo_stack.append(OperationRecord(
            op_type=OperationType.HAND_REPLACE,
            target_card=clicked_card,
            old_top_card=current_hands[1],
            start_pos=start_pos,
            end_pos=target_pos,
            replaced_card=replaced_card,
            new_left_card=new_left_card
        ))

        self.is_animating = True
        self.hand_card_view.run_move_to_animation(
            click_card=clicked_card,
            start_pos=start_pos,
            target_pos=target_pos,
            on_finish=lambda: self.on_animation_finish(clicked_card, new_left_card)
        )

    def on_animation_finish(self, new_top, new_left_card):
        self.game_state.current_hand_cards[1] = new_top
        self.game_state.top_hand_card = new_top
        current_hands = [self.config.FACE_TYPE_MAP[card.face_idx] for card in self.game_state.current_hand_cards]
        print(f"🔄 手牌区更新：左[{current_hands[0]}] → 右[{current_hands[1]}]")
        self.is_animating = False

    # 主牌区点击：游戏成功后禁用
    def on_desk_card_click(self, column, clicked_card):
        if self.is_game_success or self.is_animating:
            return
        top_hand = self.game_state.get_top_hand_card()
        if not top_hand:
            print("❌ 无顶牌，无法匹配")
            return

        top_face = top_hand.face_idx + 1
        desk_face = clicked_card.face_idx + 1
        if abs(top_face - desk_face) != 1:
            print(
                f"❌ 不匹配：顶牌[{self.config.FACE_TYPE_MAP[top_hand.face_idx]}] 与 桌面[{self.config.FACE_TYPE_MAP[clicked_card.face_idx]}]")
            return

        layer = len(self.game_state.desk_stacks[column]) - 1
        start_pos = (self.config.DESK_COLUMN_X[column], self.config.DESK_TOP_Y + layer * self.config.DESK_STACK_OFFSET)
        target_pos = (self.config.DESIGN_WIDTH // 2 - self.config.CARD_WIDTH // 2, self.config.HAND_CARD_Y)

        self.undo_stack.append(OperationRecord(
            op_type=OperationType.DESK_MATCH,
            target_card=clicked_card,
            old_top_card=top_hand,
            start_pos=start_pos,
            end_pos=target_pos,
            desk_card_index=column
        ))

        self.is_animating = True
        self.desk_card_view.run_match_animation(
            column=column,
            card=clicked_card,
            start_pos=start_pos,
            target_pos=target_pos,
            on_finish=lambda: self.on_match_finish(column, clicked_card)
        )

    # 匹配成功后检测是否游戏结束
    def on_match_finish(self, column, card):
        self.game_state.remove_desk_top_card(column)
        self.game_state.current_hand_cards[1] = card
        self.game_state.top_hand_card = card
        print(f"✅ 匹配成功！新顶牌：{self.config.FACE_TYPE_MAP[card.face_idx]}")
        self.is_animating = False
        self.check_game_success()  # 匹配成功后检测

    # 回退按钮：游戏成功后禁用
    def on_undo_click(self):
        if self.is_game_success or self.is_animating or not self.undo_stack:
            print("无回退记录")
            return
        last_op = self.undo_stack.pop()
        self.is_animating = True

        if last_op.op_type == OperationType.HAND_REPLACE:
            self.hand_card_view.run_move_to_animation(
                click_card=last_op.target_card,
                start_pos=last_op.end_pos,
                target_pos=last_op.start_pos,
                on_finish=lambda: self.on_undo_done(last_op)
            )
        elif last_op.op_type == OperationType.DESK_MATCH:
            self.desk_card_view.run_match_animation(
                column=last_op.desk_card_index,
                card=last_op.target_card,
                start_pos=last_op.end_pos,
                target_pos=last_op.start_pos,
                on_finish=lambda: self.on_undo_done(last_op)
            )

    # 修复缩进：确保每个 if 分支都有缩进块
    def on_undo_done(self, op):
        if op.op_type == OperationType.HAND_REPLACE:
            # 恢复左牌和顶牌
            self.game_state.current_hand_cards[0] = op.replaced_card
            self.game_state.current_hand_cards[1] = op.old_top_card
            self.game_state.top_hand_card = op.old_top_card
            # 恢复手牌池
            self.game_state.hand_pool.append(op.new_left_card)
            self.game_state.hand_pool.remove(op.target_card)
            current_hands = [self.config.FACE_TYPE_MAP[card.face_idx] for card in self.game_state.current_hand_cards]
            print(f"⏪ 回退完成：左[{current_hands[0]}] → 右[{current_hands[1]}]")
        elif op.op_type == OperationType.DESK_MATCH:
            # 恢复主牌区顶层牌
            self.game_state.desk_stacks[op.desk_card_index].append(op.target_card)
            # 恢复原顶牌
            self.game_state.current_hand_cards[1] = op.old_top_card
            self.game_state.top_hand_card = op.old_top_card
            print(f"⏪ 回退匹配：桌面[{self.config.FACE_TYPE_MAP[op.target_card.face_idx]}] 回到主牌区")
            self.is_game_success = False  # 回退後取消成功状态
        self.is_animating = False

    # 主循环：新增成功字样绘制和点击退出
    def run(self):
        self.running = True
        self.clock = pygame.time.Clock()
        while self.running:
            delta_time = self.clock.tick(self.config.FPS) / 1000.0
            try:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        self.running = False

                    # 游戏成功后，点击屏幕任意位置退出
                    if self.is_game_success:
                        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                            print("👋 点击屏幕，退出游戏！")
                            self.running = False
                        continue  # 跳过其他交互事件

                    # 游戏未成功时，正常处理交互
                    self.hand_card_view.handle_event(event)
                    self.desk_card_view.handle_event(event)
                    self.undo_button_view.handle_event(event)

                # 绘制背景和所有元素
                self.screen.fill(self.config.GLOBAL_BACKGROUND_COLOR)
                desk_rect = pygame.Rect(0, 0, self.config.DESIGN_WIDTH, self.config.DESK_AREA_HEIGHT)
                PygameUtils.draw_transparent_rect(self.screen, self.config.DESK_BACKGROUND_COLOR, desk_rect,
                                                  self.config.DESK_BACKGROUND_ALPHA)
                hand_rect = pygame.Rect(0, self.config.HAND_AREA_TOP_Y, self.config.DESIGN_WIDTH,
                                        self.config.HAND_AREA_HEIGHT)
                PygameUtils.draw_transparent_rect(self.screen, self.config.HAND_BACKGROUND_COLOR, hand_rect,
                                                  self.config.HAND_BACKGROUND_ALPHA)
                self.desk_card_view.draw()
                self.hand_card_view.draw()
                self.undo_button_view.draw()

                # 绘制成功字样（屏幕中央）
                if self.is_game_success:
                    success_text = self.success_font.render("成功", True, self.success_color)
                    # 文字居中计算（适配缩放）
                    text_rect = success_text.get_rect(center=(
                        self.config.DESIGN_WIDTH // 2 * self.scale_factor,
                        self.config.DESIGN_HEIGHT // 2 * self.scale_factor
                    ))
                    self.screen.blit(success_text, text_rect)

                # 更新动画
                self.hand_card_view.update(delta_time)
                self.desk_card_view.update(delta_time)

                pygame.display.flip()
            except Exception as e:
                print(f"异常：{e}")
                continue