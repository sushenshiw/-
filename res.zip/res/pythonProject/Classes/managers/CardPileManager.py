import random
from Classes.models.GameState import Card

class CardPileManager:
    def __init__(self, game_state, config):
        self.game_state = game_state
        self.config = config

    def init_piles_from_config(self, config_path=None):
        try:
            # 生成52张标准牌并打乱
            all_cards = []
            for suit_idx in range(4):
                for face_idx in range(13):
                    all_cards.append(Card(face_idx, suit_idx))
            random.shuffle(all_cards)
            print("✅ 52张牌已随机打乱")

            # 核心修改：主牌区左3+右3=6张（对称），手牌区+手牌池分配不变
            left_desk = all_cards[0:3]       # 上方主牌区左列3张
            right_desk = all_cards[3:6]      # 上方主牌区右列3张（原3:5改为3:6，多1张）
            left_hand = all_cards[6]         # 下方手牌区左普通牌
            top_hand = all_cards[7]          # 下方手牌区右顶牌
            hand_pool = all_cards[8:18]      # 手牌池10张（索引顺延，保持10张）

            # 更新游戏状态
            self.game_state.desk_stacks[0] = left_desk  # 主牌区左列（3张）
            self.game_state.desk_stacks[1] = right_desk # 主牌区右列（3张）
            self.game_state.current_hand_cards = [left_hand, top_hand]  # 手牌区
            self.game_state.hand_pool = hand_pool
            self.game_state.top_hand_card = top_hand

            # 打印调试信息（同步更新右列牌数）
            left_desk_top = self.config.FACE_TYPE_MAP[left_desk[-1].face_idx]
            right_desk_top = self.config.FACE_TYPE_MAP[right_desk[-1].face_idx]
            hand_info = [self.config.FACE_TYPE_MAP[card.face_idx] for card in [left_hand, top_hand]]
            print(f"📊 初始化完成（对称6张主牌）：")
            print(f"   - 上方主牌区：左列3张（顶层{left_desk_top}），右列3张（顶层{right_desk_top}）")
            print(f"   - 下方手牌区：左[{hand_info[0]}] → 右[{hand_info[1]}]（顶牌）")
            print(f"   - 手牌池：{len(hand_pool)}张（左牌可随机替换）")

        except Exception as e:
            print(f"❌ 随机生成失败：{str(e)}")
            self._load_default_piles()

    def _load_default_piles(self):
        """降级：默认主牌区也保持左3+右3=6张对称"""
        print("🔧 加载默认牌堆（对称6张主牌）...")
        # 主牌区（左3+右3，对称）
        left_desk = [Card(0,0), Card(1,0), Card(2,0)]  # 梅花A、2、3
        right_desk = [Card(3,1), Card(4,1), Card(5,1)]  # 方块4、5、6（原2张改为3张）
        # 手牌区
        left_hand = Card(6,2)                          # 红桃7
        top_hand = Card(7,2)                           # 红桃8
        hand_pool = [Card(8,3), Card(9,0), Card(10,1)]  # 备用牌

        self.game_state.desk_stacks[0] = left_desk
        self.game_state.desk_stacks[1] = right_desk
        self.game_state.current_hand_cards = [left_hand, top_hand]
        self.game_state.hand_pool = hand_pool
        self.game_state.top_hand_card = top_hand