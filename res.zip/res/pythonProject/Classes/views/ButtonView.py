import pygame
from Classes.views.BaseView import BaseView

class ButtonView(BaseView):
    def __init__(self, screen, scale_factor):
        super().__init__(screen, scale_factor)
        self.click_callback = None
        self.is_hover = False  # 是否 hover

        # 初始化字体
        pygame.font.init()
        self.font = pygame.font.Font(None, self.config.UNDO_BUTTON_FONT_SIZE)

    def set_click_callback(self, callback):
        self.click_callback = callback

    def draw(self):
        # 获取按钮配置
        x, y = self.config.UNDO_BUTTON_POS
        width = self.config.UNDO_BUTTON_WIDTH
        height = self.config.UNDO_BUTTON_HEIGHT

        # 缩放按钮位置和大小（适配屏幕缩放）
        scaled_x, scaled_y = self.scale_pos(x, y)
        scaled_width, scaled_height = self.scale_size(width, height)

        # 绘制按钮背景（hover时变色）
        bg_color = self.config.UNDO_BUTTON_HOVER_COLOR if self.is_hover else self.config.UNDO_BUTTON_COLOR
        pygame.draw.rect(
            self.screen,
            bg_color,
            (scaled_x, scaled_y, scaled_width, scaled_height),
            border_radius=8  # 圆角（可选，更美观）
        )
        # 绘制按钮边框
        pygame.draw.rect(
            self.screen,
            (0, 0, 0),  # 黑色边框
            (scaled_x, scaled_y, scaled_width, scaled_height),
            width=2,
            border_radius=8
        )

        # 绘制按钮文字（居中）
        text_surface = self.font.render(self.config.UNDO_BUTTON_TEXT, True, (0, 0, 0))  # 黑色文字
        text_rect = text_surface.get_rect(
            center=(scaled_x + scaled_width//2, scaled_y + scaled_height//2)
        )
        self.screen.blit(text_surface, text_rect)

    def handle_event(self, event):
        # 检测鼠标位置
        if event.type == pygame.MOUSEMOTION:
            mouse_x = event.pos[0] / self.scale_factor
            mouse_y = event.pos[1] / self.scale_factor
            x, y = self.config.UNDO_BUTTON_POS
            width = self.config.UNDO_BUTTON_WIDTH
            height = self.config.UNDO_BUTTON_HEIGHT
            # 判断是否 hover
            self.is_hover = (x <= mouse_x <= x + width) and (y <= mouse_y <= y + height)

        # 检测点击
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.is_hover and self.click_callback:
                self.click_callback()