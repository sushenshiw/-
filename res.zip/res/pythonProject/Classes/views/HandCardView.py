import pygame
from Classes.views.BaseView import BaseView

class HandCardView(BaseView):
    def __init__(self, screen, game_state, scale_factor, controller):  # 接收控制器引用
        super().__init__(screen, scale_factor)
        self.game_state = game_state
        self.controller = controller  # 保存控制器引用
        self.click_callback = None
        self.animation_data = None

    def set_click_callback(self, callback):
        self.click_callback = callback

    def run_move_to_animation(self, click_card, start_pos, target_pos, on_finish):
        self.animation_data = {
            "type": "move_to",
            "click_card": click_card,
            "start_pos": start_pos,
            "target_pos": target_pos,
            "on_finish": on_finish,
            "start_time": pygame.time.get_ticks()
        }
        self.is_animating = True

    # 修复：通过控制器访问 is_game_success
    def update(self, delta_time):
        if self.controller.is_game_success:  # 不再访问 game_state，而是控制器的属性
            return
        if not self.animation_data:
            return
        anim = self.animation_data
        elapsed = pygame.time.get_ticks() - anim["start_time"]
        progress = min(elapsed / (self.config.ANIMATION_TIME * 1000), 1.0)

        current_x = anim["start_pos"][0] + (anim["target_pos"][0] - anim["start_pos"][0]) * progress
        current_y = anim["start_pos"][1] + (anim["target_pos"][1] - anim["start_pos"][1]) * progress
        scaled_pos = self.scale_pos(current_x, current_y)
        scaled_size = self.scale_size(self.config.CARD_WIDTH, self.config.CARD_HEIGHT)

        self.utils.draw_card(self.screen, anim["click_card"], self.config, scaled_pos, scaled_size)

        if progress >= 1.0:
            self.animation_data = None
            self.is_animating = False
            anim["on_finish"]()

    def draw(self):
        current_hands = self.game_state.current_hand_cards
        if len(current_hands) < 2:
            return

        # 绘制左普通牌
        left_card = current_hands[0]
        left_x = self.config.HAND_CARD_START_X
        left_y = self.config.HAND_CARD_Y
        scaled_left_pos = self.scale_pos(left_x, left_y)
        scaled_size = self.scale_size(self.config.CARD_WIDTH, self.config.CARD_HEIGHT)
        self.utils.draw_card(self.screen, left_card, self.config, scaled_left_pos, scaled_size)

        # 绘制右顶牌（高亮边框）
        top_card = current_hands[1]
        top_x = self.config.DESIGN_WIDTH // 2 - self.config.CARD_WIDTH // 2
        top_y = self.config.HAND_CARD_Y
        scaled_top_pos = self.scale_pos(top_x, top_y)
        self.utils.draw_card(self.screen, top_card, self.config, scaled_top_pos, scaled_size)
        # 顶牌金色高亮边框
        pygame.draw.rect(
            self.screen,
            (255, 215, 0),  # 金色
            (scaled_top_pos[0]-2, scaled_top_pos[1]-2, scaled_size[0]+4, scaled_size[1]+4),
            width=4
        )

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not self.is_animating:
            mouse_x = event.pos[0] / self.scale_factor
            mouse_y = event.pos[1] / self.scale_factor
            current_hands = self.game_state.current_hand_cards
            if len(current_hands) < 2:
                return

            # 检测左普通牌点击
            left_card = current_hands[0]
            left_x = self.config.HAND_CARD_START_X
            left_rect = pygame.Rect(left_x, self.config.HAND_CARD_Y, self.config.CARD_WIDTH, self.config.CARD_HEIGHT)
            if left_rect.collidepoint(mouse_x, mouse_y) and self.click_callback:
                self.click_callback(left_card)