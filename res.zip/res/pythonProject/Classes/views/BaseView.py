import pygame
from Classes.configs.GameConfig import GameConfig
from Classes.utils.PygameUtils import PygameUtils

class BaseView:
    def __init__(self, screen, scale_factor):
        self.screen = screen
        self.config = GameConfig
        self.utils = PygameUtils
        self.scale_factor = scale_factor
        self.is_animating = False

    def draw(self):
        """绘制视图（子类必须实现）"""
        raise NotImplementedError

    def update(self, delta_time):
        """更新动画（子类按需实现）"""
        pass

    def handle_event(self, event):
        """处理事件（子类按需实现）"""
        pass

    def scale_pos(self, x, y):
        """缩放坐标（原始→窗口）"""
        return (int(x * self.scale_factor), int(y * self.scale_factor))

    def scale_size(self, w, h):
        """缩放尺寸（原始→窗口）"""
        return (int(w * self.scale_factor), int(h * self.scale_factor))