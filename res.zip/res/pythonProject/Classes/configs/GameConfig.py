import os

class GameConfig:
    DESIGN_WIDTH = 1080
    DESIGN_HEIGHT = 2080
    FPS = 60
    ANIMATION_TIME = 0.3  # 动画时长（秒）

    RES_ROOT = r"D:\工作区\浏览器文件\res\res"
    CARD_FACE_PATH_TPL = os.path.join(RES_ROOT, "number/{size}_{color}_{face}.png")
    CARD_SUIT_PATHS = [
        os.path.join(RES_ROOT, "suits/club.png"),
        os.path.join(RES_ROOT, "suits/diamond.png"),
        os.path.join(RES_ROOT, "suits/heart.png"),
        os.path.join(RES_ROOT, "suits/spade.png")
    ]

    CARD_WIDTH = 200
    CARD_HEIGHT = 280
    CARD_BORDER_WIDTH = 3
    CARD_FRONT_COLOR = (255, 255, 255)
    CARD_BORDER_COLOR = (0, 0, 0)

    # 整体背景（灰色）
    GLOBAL_BACKGROUND_COLOR = (200, 200, 200)
    # 主牌区（黄色）
    DESK_AREA_HEIGHT = 1500
    DESK_BACKGROUND_COLOR = (255, 220, 100)
    DESK_BACKGROUND_ALPHA = 255
    DESK_COLUMNS = 2
    DESK_COLUMN_X = [240, 640]
    DESK_STACK_OFFSET = 100
    DESK_TOP_Y = 200
    # 堆牌区（紫色）
    HAND_AREA_HEIGHT = 580
    HAND_AREA_TOP_Y = 1500
    HAND_BACKGROUND_COLOR = (100, 50, 120)
    HAND_BACKGROUND_ALPHA = 255
    # 左普通牌位置
    HAND_CARD_START_X = 180  # 左普通牌X坐标，确保与顶牌间距合理
    HAND_CARD_Y = 1650
    # 回退按钮
    UNDO_BUTTON_WIDTH = 140
    UNDO_BUTTON_HEIGHT = 70
    UNDO_BUTTON_POS = (DESIGN_WIDTH - 200, HAND_AREA_TOP_Y + (HAND_AREA_HEIGHT - UNDO_BUTTON_HEIGHT) // 2)
    UNDO_BUTTON_COLOR = (220, 220, 220)
    UNDO_BUTTON_HOVER_COLOR = (180, 180, 180)
    UNDO_BUTTON_FONT_SIZE = 45
    UNDO_BUTTON_TEXT = "回退"

    FACE_TYPE_MAP = {0: "A", 1: "2", 2: "3", 3: "4", 4: "5", 5: "6", 6: "7",
                    7: "8", 8: "9", 9: "10", 10: "J", 11: "Q", 12: "K"}
    SUIT_TO_COLOR_PREFIX = {0: "black", 1: "red", 2: "red", 3: "black"}
    FACE_TO_FILE_MAP = {"A": "A", "2": "2", "3": "3", "4": "4", "5": "5", "6": "6", "7": "7",
                        "8": "8", "9": "9", "10": "10", "J": "J", "Q": "Q", "K": "K"}
    CARD_FACE_SIZE = "big"

    @staticmethod
    def json_to_face_index(json_num):
        return json_num - 1 if 1 <= json_num <= 13 else 0

    @staticmethod
    def json_to_suit_index(json_num):
        return json_num if 0 <= json_num < 4 else 0