class Card:
    def __init__(self, suit_idx, face_idx, is_wild=False, config_pos=(0, 0)):
        self.suit_idx = suit_idx  # 花色索引（0-3）
        self.face_idx = face_idx  # 牌面索引（0-12）
        self.is_wild = is_wild    # 是否万能牌
        self.is_open = False      # 是否翻开
        self.config_pos = config_pos  # 原始配置位置
        self.ui_rect = None       # Pygame绘制矩形

    def get_display_text(self, config):
        """获取牌面文本（降级用）"""
        if not self.is_open:
            return "?"
        if self.is_wild:
            return "WILD"
        face_text = config.FACE_TYPE_MAP.get(self.face_idx, "?")
        suit_text = config.SUIT_TYPE_MAP.get(self.suit_idx, "无")
        return f"{face_text}({suit_text})"

    def get_face_value(self):
        """获取牌面数值（用于匹配）"""
        return self.face_idx + 1  # A=1, 2=2,...K=13