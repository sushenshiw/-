import random

class Card:
    def __init__(self, face_idx, suit_idx):
        self.face_idx = face_idx  # 0=A, 1=2, ..., 12=K
        self.suit_idx = suit_idx  # 0-3花色
        self.ui_rect = None

class GameState:
    def __init__(self):
        self.desk_stacks = [[], []]  # 桌面两列牌堆
        self.current_hand_cards = []  # [左普通牌, 右顶牌]
        self.hand_pool = []  # 备用随机牌池
        self.top_hand_card = None  # 右顶牌

    def random_replace_left_card(self):
        """随机替换左普通牌，返回新牌和被替换的旧牌"""
        if not self.hand_pool:
            return None, None
        # 取出左牌，放回牌池
        replaced_card = self.current_hand_cards[0]
        self.hand_pool.append(replaced_card)
        # 从牌池随机选新牌
        random_idx = random.randint(0, len(self.hand_pool)-1)
        new_card = self.hand_pool.pop(random_idx)
        self.current_hand_cards[0] = new_card
        return new_card, replaced_card

    def get_top_hand_card(self):
        return self.top_hand_card if self.top_hand_card in self.current_hand_cards else None

    def get_desk_top_card(self, column):
        if 0 <= column < len(self.desk_stacks) and self.desk_stacks[column]:
            return self.desk_stacks[column][-1]
        return None

    def remove_desk_top_card(self, column):
        if 0 <= column < len(self.desk_stacks) and self.desk_stacks[column]:
            return self.desk_stacks[column].pop()
        return None