from enum import Enum

class OperationType(Enum):
    """操作类型枚举"""
    HAND_REPLACE = "hand_replace"  # 手牌替换顶牌
    DESK_MATCH = "desk_match"      # 桌面牌匹配

class OperationRecord:
    """操作记录（新增 desk_card_index 参数，适配主牌区列索引）"""
    def __init__(self, op_type, target_card, old_top_card, start_pos, end_pos, desk_card_index=None, replaced_card=None, new_left_card=None):
        self.op_type = op_type
        self.target_card = target_card  # 目标卡牌（左牌/主牌区顶层牌）
        self.old_top_card = old_top_card  # 原顶牌
        self.start_pos = start_pos      # 起始位置
        self.end_pos = end_pos          # 结束位置
        self.desk_card_index = desk_card_index  # 主牌区列索引（仅 DESK_MATCH 用）
        self.replaced_card = replaced_card  # 被替换的左牌（仅 HAND_REPLACE 用）
        self.new_left_card = new_left_card  # 新生成的左牌（仅 HAND_REPLACE 用）