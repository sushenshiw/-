import pygame
import os

class PygameUtils:
    IMAGE_CACHE = {}

    @staticmethod
    def load_image(path, size=None):
        """加载图片并缓存"""
        if not path:
            return None
        if path in PygameUtils.IMAGE_CACHE:
            return PygameUtils.IMAGE_CACHE[path]
        try:
            if not os.path.exists(path):
                print(f"警告：图片缺失 -> {path}")
                return None
            img = pygame.image.load(path).convert_alpha()
            if size:
                img = pygame.transform.scale(img, size)
            PygameUtils.IMAGE_CACHE[path] = img
            return img
        except Exception as e:
            print(f"加载图片失败 -> {path}，错误：{e}")
            return None

    @staticmethod
    def load_background(path, screen_size):
        """加载背景图并缩放适配屏幕"""
        bg_img = PygameUtils.load_image(path)
        if not bg_img:
            return None
        # 缩放背景图到屏幕大小（保持比例，填充整个屏幕）
        return pygame.transform.scale(bg_img, screen_size)

    @staticmethod
    def draw_transparent_rect(screen, color, rect, alpha):
        """绘制半透明矩形（用于主牌区/堆牌区背景）"""
        # 创建临时表面，支持透明度
        temp_surface = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        # 设置颜色和透明度（color + alpha）
        r, g, b = color
        temp_surface.fill((r, g, b, alpha))
        # 绘制到屏幕
        screen.blit(temp_surface, (rect.x, rect.y))

    @staticmethod
    def draw_card(screen, card, config, pos, size):
        """仅绘制卡牌正面（白色背景+牌面+花色）"""
        x, y = pos
        w, h = size
        card_rect = pygame.Rect(x, y, w, h)

        # 1. 绘制边框+白色背景
        pygame.draw.rect(screen, config.CARD_FRONT_COLOR, card_rect)
        pygame.draw.rect(screen, config.CARD_BORDER_COLOR, card_rect, config.CARD_BORDER_WIDTH)

        # 2. 绘制牌面数字/字母（左上角）
        suit_idx = card.suit_idx
        color_prefix = config.SUIT_TO_COLOR_PREFIX.get(suit_idx, "black")
        face_text = config.FACE_TYPE_MAP.get(card.face_idx, "A")
        file_suffix = config.FACE_TO_FILE_MAP.get(face_text)

        if file_suffix:
            face_path = config.CARD_FACE_PATH_TPL.format(
                size=config.CARD_FACE_SIZE, color=color_prefix, face=file_suffix
            )
            face_size_ratio = w / config.CARD_WIDTH
            face_size = (int(100 * face_size_ratio), int(100 * face_size_ratio))
            face_img = PygameUtils.load_image(face_path, face_size)
            if face_img:
                face_x = x + int(20 * face_size_ratio)
                face_y = y + int(20 * face_size_ratio)
                screen.blit(face_img, (face_x, face_y))

        # 3. 绘制花色图标（右下角）
        if 0 <= suit_idx < len(config.CARD_SUIT_PATHS):
            suit_path = config.CARD_SUIT_PATHS[suit_idx]
            suit_size_ratio = w / config.CARD_WIDTH
            suit_size = (int(60 * suit_size_ratio), int(60 * suit_size_ratio))
            suit_img = PygameUtils.load_image(suit_path, suit_size)
            if suit_img:
                suit_x = x + w - int(80 * suit_size_ratio)
                suit_y = y + h - int(80 * suit_size_ratio)
                screen.blit(suit_img, (suit_x, suit_y))

        card.ui_rect = card_rect
        return card_rect