class MatchService:
    """匹配规则服务（点数差1，无花色要求）"""
    @staticmethod
    def can_match(desk_card, top_card):
        if not desk_card or not top_card or not desk_card.is_open or not top_card.is_open:
            return False
        # 万能牌直接匹配
        if desk_card.is_wild or top_card.is_wild:
            return True
        # 点数差1
        return abs(desk_card.get_face_value() - top_card.get_face_value()) == 1